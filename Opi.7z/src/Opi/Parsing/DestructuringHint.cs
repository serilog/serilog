﻿namespace Opi.Parsing
{
    enum DestructuringHint
    {
        Default,
        Stringify
    }
}