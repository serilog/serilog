﻿using System;
using Opi;

namespace Harness
{
    class Program
    {
        static void Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                .WithConsoleSink()
                .CreateLogger();

            Log.Information("Just biting {fruit} number {count}", "Apple", 12);
            Log.Information("Just biting {fruit} number {count:0000}", "Apple", 12);
            Log.Information("Just biting {fruit number {count}", "Apple", 12);
            Log.Information("I've eaten {dinner}", new[] { "potatoes", "peas" });
            Log.Information("I sat at {chair}", new { Back = "straight", Legs = new[] { 1, 2, 3, 4 } });
            Log.Information("I sat at {chair:s}", new { Back = "straight", Legs = new[] { 1, 2, 3, 4 } });
            Console.ReadKey(true);
        }
    }
}
